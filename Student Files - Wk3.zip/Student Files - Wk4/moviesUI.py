#!/usr/bin/env/python3

# Import db.py and class Movie from object.py
import db
from objects import Movie

# Define the global variables
CAT  = 1
YEAR = 2
ADD  = 3
DEL  = 4
EXIT = 5

COM_MENU  = "COMMAND MENU\n"
COM_MENU += f"{CAT} - View movies by category\n"
COM_MENU += f"{YEAR} - View movies by year\n"
COM_MENU += f"{ADD} - Add a movie\n"
COM_MENU += f"{DEL} - Delete a movie\n"
COM_MENU += f"{EXIT} - Exit the program\n\n"
COM_MENU += "Please select your COMMAND choice: (1-5): "

def main():

    db.connect()
    display_title()
    cat_menu = build_categories()
    while True:

        command = int(input(COM_MENU))
        if command == CAT:
            display_movies_by_category(cat_menu)

        elif command == YEAR:
            display_movies_by_year()

        elif command == ADD:
            add_movie()

        elif command == DEL:
            delete_movie()

        elif command == EXIT:
            break

        else:
            print("Not a valid command. Please try again.\n")
            display_menu()
    db.close()
    print("Bye!")

def display_title():
    print("The Movie List program\n")

    return


def build_categories():

    cat_menu = "CATEGORIES\n"

    categories = db.get_categories()
    for category in categories:
        cat_menu += str(category.id) + ". " + category.name + "\n"

    cat_menu += f"\nPlease select your CATEGORY choice: (1-{category.id}): "

    return cat_menu

def display_movies(movies, title_term):
    print("MOVIES - " + title_term)
    line_format = "{:>4s} {:37s} {:6s} {:5s} {:10s}"
    print(line_format.format("ID", "Name", "Year", "Mins", "Category"))
    print("-" * 65)
    for movie in movies:
        print(line_format.format(str(movie.id), movie.name,
                                 str(movie.year), str(movie.minutes),
                                 movie.category.name))
    print()

def display_movies_by_category(cat_menu):

    category_id = int(input(cat_menu))
    category = db.get_category(category_id)
    if category == None:
        print("There is no category with that ID.\n")
    else:
        print()
        movies = db.get_movies_by_category(category_id)
        display_movies(movies, category.name.upper())

def display_movies_by_year():
    year = int(input("Year: "))
    print()
    movies = db.get_movies_by_year(year)
    display_movies(movies, str(year))

def add_movie():
    name        = input("Name: ")
    year        = int(input("Year: "))
    minutes     = int(input("Minutes: "))
    category_id = int(input("Category ID: "))

    category = db.get_category(category_id)
    if category == None:
        print("There is no category with that ID. Movie NOT added.\n")
    else:
        movie = Movie(name=name, year=year, minutes=minutes,
                      category=category)
        db.add_movie(movie)
        print(name + " was added to database.\n")

def delete_movie():
    movie_id = int(input("Movie ID: "))
    db.delete_movie(movie_id)
    print("Movie ID " + str(movie_id) + " was deleted from database.\n")



if __name__ == "__main__":
    main()
